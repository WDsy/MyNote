package com.java.string;

/**
 * @author wei.Li by 14-8-25.
 */
public class CharSequence_ {

    private static void aVoid() {

    }
}
