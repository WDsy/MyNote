package esper.alarm;

/**
 * @author wei.Li
 */
public class AlarmHandleSetting {

    private String id;

    public AlarmHandleSetting(String id) {
        this.id = id;
    }
}
