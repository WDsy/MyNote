package commons.google.base;

/**
 * @author wei.Li by 14-8-28.
 */
public class Throwables_ {

    private static void aVoid() {

    }
}
