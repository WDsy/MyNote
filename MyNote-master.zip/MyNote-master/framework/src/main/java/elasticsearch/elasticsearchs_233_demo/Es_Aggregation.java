/*
 * Written by wei.Li and released to the public domain
 * Welcome to correct discussion as explained at
 *
 * -----------------------------------------------------------------
 *
 * GitHub:  https://github.com/GourdErwa
 * CSDN  :	http://blog.csdn.net/xiaohulunb
 * WeiBo :	http://www.weibo.com/xiaohulunb  	@GourdErwa
 * Email :	gourderwa@163.com
 *
 * Personal home page: http://grouderwa.com
 */

package elasticsearch.elasticsearchs_233_demo;

/**
 * @author wei.Li by 15/1/7 (gourderwa@163.com).
 */
public class Es_Aggregation {

    public static void main(String[] args) {


    }
}
