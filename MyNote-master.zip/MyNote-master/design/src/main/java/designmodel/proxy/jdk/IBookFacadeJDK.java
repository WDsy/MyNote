package designmodel.proxy.jdk;

/**
 * @author lw by 14-5-1.
 */
public interface IBookFacadeJDK {

    void seeBook();

}
