/*
 * Written by wei.Li and released to the public domain
 * Welcome to correct discussion as explained at
 *
 * -----------------------------------------------------------------
 *
 * GitHub:  https://github.com/GourdErwa
 * CSDN  :	http://blog.csdn.net/xiaohulunb
 * WeiBo :	http://www.weibo.com/xiaohulunb  	@GourdErwa
 * Email :	gourderwa@163.com
 *
 * Personal home page: http://grouderwa.com
 */

package designmodel.listener;

import java.util.EventObject;

/**
 * @author wei.Li by 15/3/19 (gourderwa@163.com).
 */
public class DemoEvent extends EventObject {

    public DemoEvent(Object source) {
        super(source);
        //source—事件源对象—如在界面上发生的点击按钮事件中的按钮
        //所有 Event 在构造时都引用了对象 "source"，在逻辑上认为该对象是最初发生有关 Event 的对象
    }

    public void say() {
        System.out.println("This is say method...");
    }

}
