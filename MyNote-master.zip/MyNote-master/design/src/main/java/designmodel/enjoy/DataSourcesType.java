package designmodel.enjoy;

/**
 * Created by lw on 14-5-1.
 * 数据库连接池配置类型
 */
public enum DataSourcesType {
    name1,
    name2
}
