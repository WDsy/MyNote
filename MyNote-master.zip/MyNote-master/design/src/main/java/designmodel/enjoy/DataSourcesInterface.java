package designmodel.enjoy;

import javax.sql.DataSource;

/**
 * @author lw by 14-5-1.
 */
public interface DataSourcesInterface {

    public DataSource getDataSourceByName();
}
